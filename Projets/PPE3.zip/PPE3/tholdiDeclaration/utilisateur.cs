﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace tholdiDeclaration
{
    class utilisateur
    {
        private string _login;
        private string _password;

        //select utilisateur
        private static string _selectSql =
                "SELECT login,mdp FROM utilisateur";

        public string Login { get => _login; set => _login = value; }
        public string Password { get => _password; set => _password = value; }

        //Récûpération des logins et des mots de passe des utilisateurs
        public static List<utilisateur> FetchAll()
        {
            List<utilisateur> resultat = new List<utilisateur>();
            dataBaseAccess.Connexion.Open();
            MySqlCommand commandSql = dataBaseAccess.Connexion.CreateCommand();
            commandSql.CommandText = _selectSql;
            MySqlDataReader jeuEnregistrements = commandSql.ExecuteReader();
            while (jeuEnregistrements.Read())
            {
                utilisateur u = new utilisateur();
                string login = jeuEnregistrements["login"].ToString();
                u._login = login;
                string password = jeuEnregistrements["mdp"].ToString();
                u._password = password;
                resultat.Add(u);
            }
            dataBaseAccess.Connexion.Close();
            return resultat;
        }

    }
}
