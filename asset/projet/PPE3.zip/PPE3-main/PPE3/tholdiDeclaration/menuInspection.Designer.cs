﻿
namespace tholdiDeclaration
{
    partial class menuInspection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(menuInspection));
            this.groupBoxMenu = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.numContainerInspection = new System.Windows.Forms.ComboBox();
            this.validerDecla = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.motifInspection = new System.Windows.Forms.ComboBox();
            this.commentaireInspection = new System.Windows.Forms.TextBox();
            this.numInspection = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateInscription = new System.Windows.Forms.DateTimePicker();
            this.etatInspection = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.avisInspection = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBoxMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxMenu
            // 
            this.groupBoxMenu.BackColor = System.Drawing.Color.Gray;
            this.groupBoxMenu.Controls.Add(this.button5);
            this.groupBoxMenu.Controls.Add(this.button4);
            this.groupBoxMenu.Controls.Add(this.button3);
            this.groupBoxMenu.Controls.Add(this.button2);
            this.groupBoxMenu.Controls.Add(this.button1);
            this.groupBoxMenu.Location = new System.Drawing.Point(0, 1);
            this.groupBoxMenu.Name = "groupBoxMenu";
            this.groupBoxMenu.Size = new System.Drawing.Size(116, 453);
            this.groupBoxMenu.TabIndex = 2;
            this.groupBoxMenu.TabStop = false;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(9, 91);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(98, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Inspection";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(9, 129);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(98, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Vos Déclarations";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(9, 415);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "menuUtilisateur";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 52);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Declaration";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Container";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // numContainerInspection
            // 
            this.numContainerInspection.FormattingEnabled = true;
            this.numContainerInspection.Location = new System.Drawing.Point(302, 240);
            this.numContainerInspection.Name = "numContainerInspection";
            this.numContainerInspection.Size = new System.Drawing.Size(160, 21);
            this.numContainerInspection.TabIndex = 32;
            // 
            // validerDecla
            // 
            this.validerDecla.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.validerDecla.ForeColor = System.Drawing.Color.DarkCyan;
            this.validerDecla.Location = new System.Drawing.Point(599, 366);
            this.validerDecla.Name = "validerDecla";
            this.validerDecla.Size = new System.Drawing.Size(85, 32);
            this.validerDecla.TabIndex = 30;
            this.validerDecla.Text = "Valider";
            this.validerDecla.UseVisualStyleBackColor = true;
            this.validerDecla.Click += new System.EventHandler(this.validerDecla_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(440, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 115);
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // motifInspection
            // 
            this.motifInspection.FormattingEnabled = true;
            this.motifInspection.Items.AddRange(new object[] {
            "Visite annuelle ",
            "Problème",
            "réparation d’urgence",
            "Recyclage",
            "Autre"});
            this.motifInspection.Location = new System.Drawing.Point(563, 248);
            this.motifInspection.Name = "motifInspection";
            this.motifInspection.Size = new System.Drawing.Size(172, 21);
            this.motifInspection.TabIndex = 27;
            // 
            // commentaireInspection
            // 
            this.commentaireInspection.Location = new System.Drawing.Point(302, 313);
            this.commentaireInspection.Name = "commentaireInspection";
            this.commentaireInspection.Size = new System.Drawing.Size(160, 20);
            this.commentaireInspection.TabIndex = 26;
            // 
            // numInspection
            // 
            this.numInspection.Location = new System.Drawing.Point(302, 196);
            this.numInspection.Name = "numInspection";
            this.numInspection.Size = new System.Drawing.Size(160, 20);
            this.numInspection.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(493, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Motif";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(496, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Avis";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(219, 316);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "commentaire";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(207, 276);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "date Inscription";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(197, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "numéro container";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(185, 199);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "numéro d\'inspection";
            // 
            // dateInscription
            // 
            this.dateInscription.CustomFormat = "yyyy-MM-dd";
            this.dateInscription.Location = new System.Drawing.Point(302, 280);
            this.dateInscription.Name = "dateInscription";
            this.dateInscription.Size = new System.Drawing.Size(160, 20);
            this.dateInscription.TabIndex = 28;
            // 
            // etatInspection
            // 
            this.etatInspection.FormattingEnabled = true;
            this.etatInspection.Items.AddRange(new object[] {
            "Prévue",
            "En cours",
            "Finie"});
            this.etatInspection.Location = new System.Drawing.Point(563, 292);
            this.etatInspection.Name = "etatInspection";
            this.etatInspection.Size = new System.Drawing.Size(172, 21);
            this.etatInspection.TabIndex = 34;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(493, 292);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 33;
            this.label7.Text = "Etat";
            // 
            // avisInspection
            // 
            this.avisInspection.Location = new System.Drawing.Point(563, 203);
            this.avisInspection.Name = "avisInspection";
            this.avisInspection.Size = new System.Drawing.Size(172, 20);
            this.avisInspection.TabIndex = 35;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(770, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 26);
            this.pictureBox2.TabIndex = 36;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // menuInspection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.avisInspection);
            this.Controls.Add(this.etatInspection);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.numContainerInspection);
            this.Controls.Add(this.validerDecla);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dateInscription);
            this.Controls.Add(this.motifInspection);
            this.Controls.Add(this.commentaireInspection);
            this.Controls.Add(this.numInspection);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBoxMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "menuInspection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "menuInspection";
            this.Load += new System.EventHandler(this.menuInspection_Load);
            this.groupBoxMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxMenu;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox numContainerInspection;
        private System.Windows.Forms.Button validerDecla;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox motifInspection;
        private System.Windows.Forms.TextBox commentaireInspection;
        private System.Windows.Forms.TextBox numInspection;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DateTimePicker dateInscription;
        private System.Windows.Forms.ComboBox etatInspection;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox avisInspection;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}