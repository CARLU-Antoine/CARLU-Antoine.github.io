﻿
namespace tholdiDeclaration
{
    partial class menuDeclaration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(menuDeclaration));
            this.groupBoxMenu = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.commentaireDeclaration = new System.Windows.Forms.TextBox();
            this.codeDocker = new System.Windows.Forms.TextBox();
            this.libelleProbleme = new System.Windows.Forms.ComboBox();
            this.dateDecla = new System.Windows.Forms.DateTimePicker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.validerDecla = new System.Windows.Forms.Button();
            this.traite = new System.Windows.Forms.ComboBox();
            this.urgence = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.numContainerInsert = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBoxMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxMenu
            // 
            this.groupBoxMenu.BackColor = System.Drawing.Color.Gray;
            this.groupBoxMenu.Controls.Add(this.button5);
            this.groupBoxMenu.Controls.Add(this.button4);
            this.groupBoxMenu.Controls.Add(this.button3);
            this.groupBoxMenu.Controls.Add(this.button2);
            this.groupBoxMenu.Controls.Add(this.button1);
            this.groupBoxMenu.Location = new System.Drawing.Point(0, 0);
            this.groupBoxMenu.Name = "groupBoxMenu";
            this.groupBoxMenu.Size = new System.Drawing.Size(116, 453);
            this.groupBoxMenu.TabIndex = 1;
            this.groupBoxMenu.TabStop = false;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(9, 81);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(98, 23);
            this.button5.TabIndex = 20;
            this.button5.Text = "Inspection";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(9, 124);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(98, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Vos Déclarations";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(9, 415);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "menuUtilisateur";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 52);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Declaration";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Container";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(198, 197);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "commentaire";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(198, 238);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(198, 289);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Docker";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(520, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "urgence";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(519, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "traite";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(519, 321);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "libelle";
            // 
            // commentaireDeclaration
            // 
            this.commentaireDeclaration.Location = new System.Drawing.Point(280, 190);
            this.commentaireDeclaration.Name = "commentaireDeclaration";
            this.commentaireDeclaration.Size = new System.Drawing.Size(160, 20);
            this.commentaireDeclaration.TabIndex = 8;
            // 
            // codeDocker
            // 
            this.codeDocker.Location = new System.Drawing.Point(280, 286);
            this.codeDocker.Name = "codeDocker";
            this.codeDocker.Size = new System.Drawing.Size(160, 20);
            this.codeDocker.TabIndex = 10;
            // 
            // libelleProbleme
            // 
            this.libelleProbleme.FormattingEnabled = true;
            this.libelleProbleme.Items.AddRange(new object[] {
            "Corrosion",
            "Choc sur container",
            "Gong défectueux",
            "paroi percée",
            "système de fermeture défectueux",
            "pb réfrigération",
            "Autre"});
            this.libelleProbleme.Location = new System.Drawing.Point(586, 318);
            this.libelleProbleme.Name = "libelleProbleme";
            this.libelleProbleme.Size = new System.Drawing.Size(121, 21);
            this.libelleProbleme.TabIndex = 13;
            // 
            // dateDecla
            // 
            this.dateDecla.CustomFormat = "yyyy-MM-dd";
            this.dateDecla.Location = new System.Drawing.Point(280, 231);
            this.dateDecla.Name = "dateDecla";
            this.dateDecla.Size = new System.Drawing.Size(160, 20);
            this.dateDecla.TabIndex = 14;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(418, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 115);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // validerDecla
            // 
            this.validerDecla.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.validerDecla.ForeColor = System.Drawing.Color.DarkCyan;
            this.validerDecla.Location = new System.Drawing.Point(622, 362);
            this.validerDecla.Name = "validerDecla";
            this.validerDecla.Size = new System.Drawing.Size(85, 32);
            this.validerDecla.TabIndex = 16;
            this.validerDecla.Text = "Valider";
            this.validerDecla.UseVisualStyleBackColor = true;
            this.validerDecla.Click += new System.EventHandler(this.validerDecla_Click);
            // 
            // traite
            // 
            this.traite.FormattingEnabled = true;
            this.traite.Items.AddRange(new object[] {
            "traite",
            "non traité"});
            this.traite.Location = new System.Drawing.Point(586, 229);
            this.traite.Name = "traite";
            this.traite.Size = new System.Drawing.Size(121, 21);
            this.traite.TabIndex = 17;
            // 
            // urgence
            // 
            this.urgence.FormattingEnabled = true;
            this.urgence.Items.AddRange(new object[] {
            "urgent",
            "non"});
            this.urgence.Location = new System.Drawing.Point(586, 187);
            this.urgence.Name = "urgence";
            this.urgence.Size = new System.Drawing.Size(121, 21);
            this.urgence.TabIndex = 18;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(772, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 26);
            this.pictureBox2.TabIndex = 19;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // numContainerInsert
            // 
            this.numContainerInsert.FormattingEnabled = true;
            this.numContainerInsert.Items.AddRange(new object[] {
            "Corrosion",
            "Choc sur container",
            "Gong défectueux",
            "paroi percée",
            "système de fermeture défectueux",
            "pb réfrigération",
            "Autre"});
            this.numContainerInsert.Location = new System.Drawing.Point(586, 270);
            this.numContainerInsert.Name = "numContainerInsert";
            this.numContainerInsert.Size = new System.Drawing.Size(121, 21);
            this.numContainerInsert.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(476, 273);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "numéro de container";
            // 
            // menuDeclaration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.numContainerInsert);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.urgence);
            this.Controls.Add(this.traite);
            this.Controls.Add(this.validerDecla);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dateDecla);
            this.Controls.Add(this.libelleProbleme);
            this.Controls.Add(this.codeDocker);
            this.Controls.Add(this.commentaireDeclaration);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBoxMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "menuDeclaration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "menuDeclaration";
            this.Load += new System.EventHandler(this.menuDeclaration_Load);
            this.groupBoxMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxMenu;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox commentaireDeclaration;
        private System.Windows.Forms.TextBox codeDocker;
        private System.Windows.Forms.ComboBox libelleProbleme;
        private System.Windows.Forms.DateTimePicker dateDecla;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button validerDecla;
        private System.Windows.Forms.ComboBox traite;
        private System.Windows.Forms.ComboBox urgence;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox numContainerInsert;
        private System.Windows.Forms.Label label7;
    }
}